print("please insert radius of circle  r = ")
radius = input()
pi = 3.14
circumference = pi * 2 * float(radius)
area = pi * float(radius)**2
print(f'circumference={circumference}   and Area = {area}')
