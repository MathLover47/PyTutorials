"""greeting = '''
hi
it's me nedal
how are you?
godbye!
'''
print(greeting)
"""
str01 = "MathLover is First Computer Programmer of all famous PROGRAMMING LANGUAGES"
print(str01.upper())
print(str01.lower())
print(str01.find("Programmer"))
print(str01.replace("Programmer","Idiot"))
str02 = f'{str01} to prove it see him {str01.replace("Computer","stupid")}'
print(str01)
print(str02)
