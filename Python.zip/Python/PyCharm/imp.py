# from defClass import Person

# x1 = Person("1234")
# x1.talk()
import defClass
x2 = defClass.Person("MathLover47")
x2.talk()
x2.name = "Nedal AbuRuqaya"
x2.talk()
