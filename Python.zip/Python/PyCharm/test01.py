name = "MY Name is Nedal Ahmed Husein AbuRuqaya"
print(name.upper())
print(name[0])
print(name[0:7])
print(name[:4])
print(name[8:])
print(name[-9:-1])
print(name[::3])