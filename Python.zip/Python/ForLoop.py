list1 = [2,2,2,2,2,8]
for i in range(6):
    str1 = ""
    for j in range(0,list1[i]):
        str1 += "*"
    print(str1)